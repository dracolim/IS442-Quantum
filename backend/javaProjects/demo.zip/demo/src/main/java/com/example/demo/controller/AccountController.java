package com.example.demo.controller;

import com.example.demo.dao.AccountDAO;
import com.example.demo.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class AccountController {
    @Autowired
    private AccountDAO eDAO;
    @GetMapping("/accounts")
    public List<Account> getAccounts(){
        return eDAO.getAll();
    };
    @GetMapping("accounts/{id}")
    public Account getAccountById(@PathVariable int id) {
        return eDAO.getById(id);
    }
    @PostMapping("/accounts")
    public String createAccount(@RequestBody Account account){
        return eDAO.create(account) + ": No.of rows inserted";

    }
    @PutMapping("accounts/{id}")
    public String updateAccount(@RequestBody Account account, @PathVariable int id){
        return eDAO.update(account,id)+"No. of rows updated";
    };
    @DeleteMapping("/accounts/{id}")
    public String deleteAccount(@PathVariable int id){
        return eDAO.delete(id)+"No. of rows deleted";
    }


}
