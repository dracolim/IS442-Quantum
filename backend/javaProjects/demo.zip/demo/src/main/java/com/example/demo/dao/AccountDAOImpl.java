package com.example.demo.dao;

import com.example.demo.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AccountDAOImpl implements AccountDAO{
    @Autowired
    JdbcTemplate jdbcTemplate;
    @Override
    public int create(Account account) {
        return jdbcTemplate.update("INSERT INTO accounts(firstName,lastName,email) Values (?,?,?)", new Object[] {account.getFirstName(),account.getLastName(),account.getEmail()});

    }

    @Override
    public int update(Account account, int id) {
        return jdbcTemplate.update("update accounts set firstName=?, lastName=?, email=? where id=?",new Object[] {account.getFirstName(),account.getLastName(),account.getEmail(),id});
    }

    @Override
    public int delete(int id) {
        return jdbcTemplate.update("DELETE FROM accounts Where id=?",id);
    }

    @Override
    public List<Account> getAll() {

        return jdbcTemplate.query("SELECT * FROM accounts", new BeanPropertyRowMapper<Account>(Account.class));
    }

    @Override
    public Account getById(int id) {
        return jdbcTemplate.queryForObject("SELECT * FROM accounts",new BeanPropertyRowMapper<Account>(Account.class),id);

    }
}
