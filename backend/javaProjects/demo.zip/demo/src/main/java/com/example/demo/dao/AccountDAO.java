package com.example.demo.dao;

import com.example.demo.model.Account;

import java.util.List;

public interface AccountDAO {
    int create(Account account);

    int update(Account account, int id);

    int delete(int id);

    List<Account> getAll();

    Account getById(int id);


}
